module.exports = client => {
  console.log(`Yeniden başlatılıyor Reis ${new Date()}`);
};